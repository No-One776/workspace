package gvprojects.superttt.model;

import static org.junit.Assert.assertEquals;
import gvprojects.sttt.model.CellState;
import gvprojects.sttt.model.GameStatus;

import org.junit.Test;

public class SuperTicTacToeModel_Test {
	/**
	 * Tests for the SuperTicTacToeModel class
	 * 
	 * IMPORTANT: This file gives you examples of how you can thoroughly test
	 * your game engine by using its public interface. These test are not
	 * anywhere complete. They don't test every method, nor do they test every
	 * situation. You will need to add many more. For example: # Make sure
	 * everybody wins # What about ties? (board full) # Can the user give
	 * invalid input?
	 * 
	 * @author Justin Rohr
	 */

	@Test
	public void constructorSetsNumRowsCorrectly() throws Throwable {
		SuperTicTacToeModel engine = new SuperTicTacToeModel<Object>(10, 3, 5);
		assertEquals(10, engine.numRows());
	}

	@Test
	public void constructorSetsNumRowsCorrectly1() throws Throwable {
		SuperTicTacToeModel engine = new SuperTicTacToeModel(15, 3, 5);
		assertEquals(15, engine.numRows());
	}

	@Test
	public void constructorSetsNumColumnsCorrectly() throws Throwable {
		SuperTicTacToeModel engine = new SuperTicTacToeModel<Object>(3, 10, 5);
		assertEquals(10, engine.numColumns());
	}

	@Test
	public void constructorSetsNumColumnsCorrectly1() throws Throwable {
		SuperTicTacToeModel engine = new SuperTicTacToeModel<Object>(3, 1, 5);
		assertEquals(1, engine.numColumns());
	}

	@Test
	public void constructorCreatesAnEmptyBoard() throws Throwable {
		SuperTicTacToeModel engine = new SuperTicTacToeModel<Object>(4, 3, 5);
		for (int r = 0; r < engine.numRows(); r++) {
			for (int c = 0; c < engine.numColumns(); c++) {
				assertEquals(CellState.EMPTY, engine.cellStatus(r, c));
			}
		}
	}

	@Test
	public void selectSetsCell() throws Throwable {
		SuperTicTacToeModel engine = new SuperTicTacToeModel<Object>(10, 7, 5);
		engine.select(3, 4);
		assertEquals(CellState.X, engine.cellStatus(3, 4));
	}

	@Test
	public void resetSetsToZero() {
		SuperTicTacToeModel test = new SuperTicTacToeModel(2, 2, 1); 
		test.reset();
		assertEquals(0, test.numRows());
	}
	
	@Test
	public void resetSetsColsToZero() {
		SuperTicTacToeModel test = new SuperTicTacToeModel(2, 2, 1); 
		test.reset();
		assertEquals(0, test.numColumns());
	}

	// Many of my tests will look like this. See notes below for short-cuts.
	@Test
	public void engineDetectsWin() throws Throwable {
		SuperTicTacToeModel engine = new SuperTicTacToeModel<Object>(10, 7, 3);
		engine.select(0, 0);
		assertEquals(GameStatus.IN_PROGRESS, engine.status());
		engine.select(1, 0);
		assertEquals(GameStatus.IN_PROGRESS, engine.status());
		engine.select(0, 1);
		assertEquals(GameStatus.IN_PROGRESS, engine.status());
		engine.select(1, 1);
		assertEquals(GameStatus.IN_PROGRESS, engine.status());
		engine.select(0, 2);
		assertEquals(GameStatus.X_WON, engine.status());
	}

	// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	// IMPORTANT:
	//
	// The code below gives an example of how you *could* use helper methods to
	// simplify the testing of your game engine. You are *not required* to make
	// this code work with your code. You
	// are more than welcome to take a different approach to testing. Just be
	// sure to test thoroughly.
	//
	// /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// My solution uses a "package private" method "static CellState
	// checkWin(CellState[][] board, int win_length)
	// This "helper" method allows me to easily create game boards with which I
	// can test this method.
	private CellState[][] buildGameBoard(String[] description) {
		CellState[][] answer = new CellState[description.length][description[0]
				.length()];
		for (int r = 0; r < description.length; r++) {
			for (int c = 0; c < description[r].length(); c++) {
				switch (description[r].charAt(c)) {
				case 'x':
					answer[r][c] = CellState.X;
					break;
				case 'o':
					answer[r][c] = CellState.O;
					break;
				case '.':
					answer[r][c] = CellState.EMPTY;
					break;
				default:
					throw new IllegalArgumentException(
							"Illegal format character");
				}
			}
		}
		return answer;
	}

	@SuppressWarnings("deprecation")
	@Test
	public void emptyBoardReturnsNull() throws Throwable {
		String[] board_description = { ".....", ".....", "....." };
		CellState[][] game_board = buildGameBoard(board_description);
		assertEquals(null, SuperTicTacToeModel.checkForWin(game_board, 4));
	}

	@Test
	public void detectsXWininBottomRow() throws Throwable {
		String[] board_description = { ".......", ".......", ".xxxx." };
		CellState[][] game_board = buildGameBoard(board_description);
		assertEquals(CellState.X,
				SuperTicTacToeModel.checkForWin(game_board, 4));
	}

	@Test
	public void detectsOWininBottomRow() throws Throwable {
		String[] board_description = { ".......", ".......", ".oooo." };
		CellState[][] game_board = buildGameBoard(board_description);
		assertEquals(CellState.O,
				SuperTicTacToeModel.checkForWin(game_board, 4));
	}

	@Test
	public void detectsXWinInColumn() throws Throwable {
		String[] board_description = { "x......", "x......", "x......" };
		CellState[][] game_board = buildGameBoard(board_description);
		assertEquals(CellState.X,
				SuperTicTacToeModel.checkForWin(game_board, 3));
	}

	@Test
	public void detectsOWinInColumn() throws Throwable {
		String[] board_description = { "o......", "o......", "o......" };
		CellState[][] game_board = buildGameBoard(board_description);
		assertEquals(CellState.O,
				SuperTicTacToeModel.checkForWin(game_board, 3));
	}

	@Test
	public void detectsXWinInEndColumn() throws Throwable {
		String[] board_description = { "......x", "......x", "......x" };
		CellState[][] game_board = buildGameBoard(board_description);
		assertEquals(CellState.X,
				SuperTicTacToeModel.checkForWin(game_board, 3));
	}

	@Test
	public void detectsOWinInEndColumn() throws Throwable {
		String[] board_description = { "......o", "......o", "......o" };
		CellState[][] game_board = buildGameBoard(board_description);
		assertEquals(CellState.O,
				SuperTicTacToeModel.checkForWin(game_board, 3));
	}

	@Test
	public void detectsTieGame() throws Throwable {
		String[] board_description = { "xoxoxox", "oxoxoxo", "xoxoxox" };
		CellState[][] game_board = buildGameBoard(board_description);
		assertEquals(CellState.X,
				SuperTicTacToeModel.checkForWin(game_board, 6));
		assertEquals(CellState.O,
				SuperTicTacToeModel.checkForWin(game_board, 6));
	}

	@SuppressWarnings("deprecation")
	@Test
	public void doesNotDetectWinIfNotLongEnough() throws Throwable {
		String[] board_description = { "......", "......", ".xxxx." };
		CellState[][] game_board = buildGameBoard(board_description);
		assertEquals(null, SuperTicTacToeModel.checkForWin(game_board, 5));
	}

	@SuppressWarnings("rawtypes")
	@Test(expected = IllegalArgumentException.class)
	public void constructorShouldThrowExceptionIfPassedNegativeRow() {
		new SuperTicTacToeModel(-1, 2, 5);
	}

	@SuppressWarnings("rawtypes")
	@Test(expected = IllegalArgumentException.class)
	public void constructorShouldThrowExceptionIfPassedNegativeCol() {
		new SuperTicTacToeModel(1, -1, 5);
	}

	@SuppressWarnings("rawtypes")
	@Test(expected = IllegalArgumentException.class)
	public void constructorShouldThrowExceptionIfPassedNegativeWin() {
		new SuperTicTacToeModel(4, 4, -1);
	}

	@SuppressWarnings("rawtypes")
	@Test(expected = IllegalArgumentException.class)
	public void constructorShouldThrowExceptionIfPassedZeroRow() {
		new SuperTicTacToeModel(0, 5, 2);
	}

	@SuppressWarnings("rawtypes")
	@Test(expected = IllegalArgumentException.class)
	public void constructorShouldThrowExceptionIfPassedZeroCol() {
		new SuperTicTacToeModel(3, 0, 1);
	}

	@SuppressWarnings("rawtypes")
	@Test(expected = IllegalArgumentException.class)
	public void constructorShouldThrowExceptionIfPassedNullRow() {
		new SuperTicTacToeModel((Integer) null, 2, 5);
	}

	@SuppressWarnings("rawtypes")
	@Test(expected = IllegalArgumentException.class)
	public void constructorShouldThrowExceptionIfPassedNullCol() {
		new SuperTicTacToeModel(1, (Integer) null, 5);
	}

	@SuppressWarnings("rawtypes")
	@Test(expected = IllegalArgumentException.class)
	public void constructorShouldThrowExceptionIfWinLengthIsLongerThanBoard() {
		new SuperTicTacToeModel(1, 2, 5);
	}

	public void constructorShouldThrowExceptionIfBoardIsOversize() {
		new SuperTicTacToeModel(251, 251, 55);
	}

}
