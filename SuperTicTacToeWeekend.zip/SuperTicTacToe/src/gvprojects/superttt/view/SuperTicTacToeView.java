package gvprojects.superttt.view;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class SuperTicTacToeView {
	JFrame main;
	JPanel board;
//Buttons,layout managers, frames etc
}
