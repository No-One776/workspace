To run the CountDownTimerGUI just run its main method

To run Kurma's Tests run the main method in CountDownTimer

To run my tests run the main method in CountDownTimerTest

Enjoy!